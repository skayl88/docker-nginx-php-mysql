<?php   

$id = $_POST['id'];
$sum = $_POST['sum'];
$clientid = $_POST['clientid'];
$orderid = $_POST['orderid'];
$key = $_POST['key'];
$phone = $_POST['client_phone'];
$email = $_POST['client_email'];

// Multiple recipients
$to = 'zakaz@ollatelecom.ru'; // note the comma
  
// Subject
$subject = 'Новая оплата';

// Message
$message = '
<html>
<head>
  <title>Новая оплата</title>
</head>
<body>
  <table>
    <tr>
     <td>Имя  </td><td>' . $clientid . '</td>
    </tr>
    <tr>
     <td>Телефон  </td><td>' . $phone . '</td>
    </tr>
    <tr>
    <td>Почта </td><td>' . $email. '</td>
       </tr>
       <tr>
       <td>Сумма  </td><td>' . $sum. '</td>
     </tr>
     <tr>
    <td>Хеш </td><td>' .$hash. '</td>
        </tr>
      
  </table>
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'To: Olla <zakaz@ollatelecom.ru>';
$headers[] = 'From: Paykeeper <noreply@paykeeper.com>';
// Mail it
mail($to, $subject, $message, implode("\r\n", $headers));
  $queryUrl = 'https://ollatelecom.bitrix24.ru/rest/20/b4wzwemai84tloit/crm.lead.add.json';
  // формируем параметры для создания лида в переменной $queryData
  $queryData = http_build_query(array(
      'fields' => array(
  'TITLE' => 'Оплата',
  'NAME' => $clientid,
  'OPPORTUNITY' =>$sum,
 'UF_CRM_1595404150' => 'Y',
  'EMAIL' => Array(
         "n0" => Array(
             "VALUE" => "$email",
         ),
     ),
     'PHONE' => Array(
         "n0" => Array(
             "VALUE" => "$phone",
         ),
     ),
),
      'params' => array("REGISTER_SONET_EVENT" => "Y")
  ));
  // обращаемся к Битрикс24 при помощи функции curl_exec
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_POST => 1,
    CURLOPT_HEADER => 0,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $queryUrl,
    CURLOPT_POSTFIELDS => $queryData,
    CURLOPT_USERAGENT =>  'api',
    CURLOPT_TIMEOUT =>  1,
    CURLOPT_HEADER =>  0,
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_FORBID_REUSE =>  true,
    CURLOPT_CONNECTTIMEOUT =>  5,
    CURLOPT_DNS_CACHE_TIMEOUT => 2,
    CURLOPT_FRESH_CONNECT =>true,
  ));
  $result = curl_exec($curl);
  curl_close($curl);
  $result = json_decode($result, 1);

  

?>