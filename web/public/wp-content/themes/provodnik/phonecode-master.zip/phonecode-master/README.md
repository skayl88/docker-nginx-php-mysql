Просто откройте example.html и все понятно :-)

Подробно про виджет http://jakulov.ru/blog/2014/phonecode_widget
